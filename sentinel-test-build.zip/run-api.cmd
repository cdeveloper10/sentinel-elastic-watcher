@echo off
rem The control plane: REST API and console. Several of these can run against one engine.
rem The port is overridable: run-api.cmd http://0.0.0.0:8080

setlocal
set URLS=%~1
if "%URLS%"=="" set URLS=http://0.0.0.0:8080

cd /d "%~dp0api"
set ASPNETCORE_URLS=%URLS%
dotnet Sentinel.Api.dll
