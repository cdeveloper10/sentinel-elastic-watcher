@echo off
rem The detection engine. Exactly one of these.
rem
rem It evaluates every armed rule and runs their actions for real. Starting it against a database whose
rem rules are armed will send real messages, so arm nothing you are not ready to receive.
rem
rem   run-engine.cmd            evaluate
rem   run-engine.cmd --migrate  apply the schema and stop, without evaluating anything

setlocal
cd /d "%~dp0engine"
dotnet Sentinel.Engine.dll %*
