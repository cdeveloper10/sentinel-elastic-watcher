@echo off
rem A stand-in for whatever service Sentinel calls, so a rule can be proved end to end without sending a
rem real message to a real person. Run two on two ports to model two services.
rem
rem   run-service-stub.cmd 9310 sms-gateway
rem   run-service-stub.cmd 9320 security-api
rem
rem GET http://localhost:<port>/received  shows exactly what it was sent, newest first.
rem
rem It is a sample: no authentication, everything in memory. It must not be deployed.

setlocal
set PORT=%~1
if "%PORT%"=="" set PORT=9310

set STUB_NAME=%~2
if "%STUB_NAME%"=="" set STUB_NAME=service stub

cd /d "%~dp0service-stub"
dotnet ServiceStub.dll --urls http://0.0.0.0:%PORT%
